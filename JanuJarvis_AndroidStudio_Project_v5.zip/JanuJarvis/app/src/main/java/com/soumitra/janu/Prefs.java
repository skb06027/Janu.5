package com.soumitra.janu;

import android.content.Context;
import android.content.SharedPreferences;

/** Tiny SharedPreferences wrapper. */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("janu", Context.MODE_PRIVATE);
    }

    static String str(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void put(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static boolean bool(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static void put(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    static int integer(Context c, String k, int d) { return sp(c).getInt(k, d); }
    static void put(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }

    static String geminiKey(Context c, int slot) {
        return str(c, slot == 1 ? "key1" : "key2", "").trim();
    }
    static String model(Context c) { return str(c, "model", "gemini-flash-lite-latest").trim(); }
    static String lang(Context c) { return str(c, "lang", "hi-IN"); }
    static boolean hindi(Context c) { return lang(c).startsWith("hi"); }
    static boolean wake(Context c) { return bool(c, "wake", true); }
    static int voice(Context c) {
        int v = integer(c, "voice", 0);
        return (v < 0 || v >= VoiceProfile.ALL.length) ? 0 : v;
    }

    static String customUrl(Context c) { return str(c, "c_url", "https://api.openai.com/v1").trim(); }
    static String customKey(Context c) { return str(c, "c_key", "").trim(); }
    static String customModel(Context c) { return str(c, "c_model", "gpt-4o-mini").trim(); }

    /** A key counts as verified only while it is unchanged since it was verified. */
    static void markVerified(Context c, String id, String secret, long ms) {
        sp(c).edit().putString("ver_" + id, secret).putInt("ms_" + id, (int) ms).apply();
    }
    static boolean isVerified(Context c, String id, String secret) {
        return secret != null && !secret.isEmpty() && secret.equals(str(c, "ver_" + id, ""));
    }
    static int verifiedMs(Context c, String id) { return integer(c, "ms_" + id, 0); }

    static boolean anyVerified(Context c) {
        return isVerified(c, "g1", geminiKey(c, 1)) || isVerified(c, "g2", geminiKey(c, 2))
                || isVerified(c, "custom", customKey(c));
    }
    static boolean hasAnyKey(Context c) {
        return !geminiKey(c, 1).isEmpty() || !geminiKey(c, 2).isEmpty() || !customKey(c).isEmpty();
    }
}
