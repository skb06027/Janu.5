package com.soumitra.janu;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Glowing animated AI orb (like the Android / Gemini / ChatGPT voice circle). */
public class OrbView extends View {
    public static final int IDLE = 0, LISTENING = 1, THINKING = 2, SPEAKING = 3;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private int color = 0xFFB46BFF;
    private int state = IDLE;
    private float level, targetLevel;
    private final long t0 = SystemClock.uptimeMillis();
    private ValueAnimator ticker, colorAnim;

    public OrbView(Context c) { super(c); }
    public OrbView(Context c, AttributeSet a) { super(c, a); }
    public OrbView(Context c, AttributeSet a, int s) { super(c, a, s); }

    public void setState(int s) { state = s; }

    /** 0..1 microphone loudness while listening. */
    public void setLevel(float l) {
        if (state == LISTENING) targetLevel = Math.max(0f, Math.min(1f, l));
    }

    public void setColorAnimated(int to) {
        if (colorAnim != null) colorAnim.cancel();
        colorAnim = ValueAnimator.ofObject(new ArgbEvaluator(), color, to);
        colorAnim.setDuration(550);
        colorAnim.addUpdateListener(a -> { color = (Integer) a.getAnimatedValue(); invalidate(); });
        colorAnim.start();
    }

    public void setColorNow(int c) { color = c; invalidate(); }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ticker = ValueAnimator.ofFloat(0f, 1f);
        ticker.setDuration(1000);
        ticker.setRepeatCount(ValueAnimator.INFINITE);
        ticker.setInterpolator(new LinearInterpolator());
        ticker.addUpdateListener(a -> {
            float t = (SystemClock.uptimeMillis() - t0) / 1000f;
            if (state == SPEAKING) {
                targetLevel = 0.3f + 0.4f * Math.abs((float) Math.sin(t * 7.3f))
                        * (0.6f + 0.4f * (float) Math.sin(t * 2.1f));
            } else if (state == THINKING) targetLevel = 0.22f;
            else if (state == IDLE) targetLevel = 0.04f;
            level += (targetLevel - level) * 0.18f;
            invalidate();
        });
        ticker.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (ticker != null) ticker.cancel();
        if (colorAnim != null) colorAnim.cancel();
        super.onDetachedFromWindow();
    }

    private static int alpha(int c, int a) { return (c & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24); }

    private static int mix(int c1, int c2, float f) {
        int r = (int) (((c1 >> 16) & 255) * (1 - f) + ((c2 >> 16) & 255) * f);
        int g = (int) (((c1 >> 8) & 255) * (1 - f) + ((c2 >> 8) & 255) * f);
        int b = (int) ((c1 & 255) * (1 - f) + (c2 & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
        float base = Math.min(w, h) / 2f;
        float dp = getResources().getDisplayMetrics().density;
        float t = (SystemClock.uptimeMillis() - t0) / 1000f;
        float breathe = (float) Math.sin(t * 1.6f) * 0.03f;
        float r = base * 0.5f * (1f + breathe + level * 0.28f);

        // outer glow
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, base,
                new int[]{alpha(color, (int) (110 + 120 * level)), alpha(color, 45), 0},
                new float[]{0.3f, 0.68f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, base, p);
        p.setShader(null);

        // rotating rings
        float speed = state == THINKING ? 340f : state == LISTENING ? 130f : state == SPEAKING ? 95f : 45f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 3; i++) {
            float rr = r * (1.2f + 0.17f * i) + level * dp * 9f * (i + 1);
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr);
            p.setStrokeWidth(dp * (2.8f - i * 0.7f));
            p.setColor(alpha(color, 235 - i * 55));
            float dir = (i % 2 == 0) ? 1f : -1f;
            float start = t * speed * dir * (1f + i * 0.35f) + i * 70f;
            float sweep = 105f + i * 28f;
            canvas.drawArc(rect, start, sweep, false, p);
            canvas.drawArc(rect, start + 180f, sweep * 0.6f, false, p);
        }
        p.setStrokeWidth(dp);
        p.setColor(alpha(color, 55));
        canvas.drawCircle(cx, cy, r * 1.62f, p);

        // glowing core
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx - r * 0.25f, cy - r * 0.3f, r * 1.25f,
                new int[]{mix(color, 0xFFFFFFFF, 0.8f), color, mix(color, 0xFF000000, 0.55f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, r, p);
        p.setShader(null);
    }
}
