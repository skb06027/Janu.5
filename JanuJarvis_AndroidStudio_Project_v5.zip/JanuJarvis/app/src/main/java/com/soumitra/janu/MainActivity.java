package com.soumitra.janu;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements JanuService.UiListener {

    private static final int REQ_PERMS = 100;

    private OrbView orb;
    private TextView status, transcript, badge, banner;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        orb = findViewById(R.id.orb);
        status = findViewById(R.id.status);
        transcript = findViewById(R.id.transcript);
        badge = findViewById(R.id.badge);
        banner = findViewById(R.id.banner);

        orb.setColorNow(VoiceProfile.ALL[Prefs.voice(this)].color);
        orb.setOnClickListener(v -> talk());
        orb.setOnLongClickListener(v -> {
            // Resume hands-free "Hey Janu" listening (it pauses after a song starts so music is not interrupted).
            startJanu(JanuService.A_HANDSFREE);
            Toast.makeText(this, "Hands-free ON", Toast.LENGTH_SHORT).show();
            return true;
        });
        findViewById(R.id.btnSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        banner.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        buildQuickRow();

        if (!missingRuntimePermissions().isEmpty() && !Prefs.bool(this, "asked_perms", false)) {
            Prefs.put(this, "asked_perms", true);
            showWelcome();
        } else if (hasMic()) {
            JanuService.mediaMode = false;
            startJanu(JanuService.A_START);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        JanuService.ui = this;
        orb.setColorAnimated(VoiceProfile.ALL[Prefs.voice(this)].color); // voice is chosen in Settings
        renderBadge();
        renderBanner();
        applyState(JanuService.lastState, JanuService.lastStatus);
        if (!JanuService.lastText.isEmpty()) transcript.setText(JanuService.lastText);
        if (hasMic() && !JanuService.running) startJanu(JanuService.A_START);
    }

    @Override protected void onPause() {
        if (JanuService.ui == this) JanuService.ui = null;
        super.onPause();
    }

    // ------------------------------------------------------------------ service control

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void startJanu(String action) {
        if (!hasMic()) return;
        Intent i = new Intent(this, JanuService.class).setAction(action);
        startForegroundService(i);
    }

    private void talk() {
        if (!hasMic()) { requestPermissions(missingRuntimePermissions().toArray(new String[0]), REQ_PERMS); return; }
        startJanu(JanuService.A_TALK);
    }

    // ------------------------------------------------------------------ permissions

    private List<String> missingRuntimePermissions() {
        List<String> need = new ArrayList<>();
        String[] all = Build.VERSION.SDK_INT >= 33
                ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}
                : new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE};
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        return need;
    }

    private void showWelcome() {
        new AlertDialog.Builder(this)
            .setTitle("Janu ko permissions chahiye")
            .setMessage("Mic (sunne ke liye), Contacts (WhatsApp/call ke liye), Phone (call ke liye) aur Notifications.\n\n"
                    + "Uske baad Settings mein Accessibility aur Overlay ON karna hoga taaki Janu dusre apps mein kaam kar sake.")
            .setCancelable(false)
            .setPositiveButton("Allow", (d, w) -> requestPermissions(missingRuntimePermissions().toArray(new String[0]), REQ_PERMS))
            .show();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_PERMS) return;
        if (hasMic()) startJanu(JanuService.A_START);
        renderBanner();
        if (!accessibilityEnabled() || !Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Ek aur step")
                .setMessage("Accessibility aur 'Display over other apps' ON kijiye, tab Janu YouTube/WhatsApp/Instagram/Facebook mein khud kaam karega.")
                .setPositiveButton("Settings kholo", (d, w) -> startActivity(new Intent(this, SettingsActivity.class)))
                .setNegativeButton("Baad mein", null)
                .show();
        }
    }

    private boolean accessibilityEnabled() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        String full = new ComponentName(this, JanuAccessibilityService.class).flattenToString();
        String shortName = new ComponentName(this, JanuAccessibilityService.class).flattenToShortString();
        return s.contains(full) || s.contains(shortName);
    }

    // ------------------------------------------------------------------ UI

    private void renderBadge() {
        boolean verified = Prefs.anyVerified(this);
        if (verified) {
            badge.setText("✔ Verified • ⚡ Ultra Fast");
            badge.setTextColor(Color.parseColor("#7CFFB2"));
        } else if (Prefs.hasAnyKey(this)) {
            badge.setText("Key added • Verify in Settings");
            badge.setTextColor(Color.parseColor("#FFD27C"));
        } else {
            badge.setText("No API key");
            badge.setTextColor(Color.parseColor("#FFB4C0"));
        }
    }

    private void renderBanner() {
        List<String> issues = new ArrayList<>();
        if (!hasMic()) issues.add("Mic permission");
        if (!accessibilityEnabled()) issues.add("Accessibility");
        if (!Settings.canDrawOverlays(this)) issues.add("Overlay");
        if (!Prefs.hasAnyKey(this)) issues.add("Gemini API key");
        if (issues.isEmpty()) { banner.setVisibility(View.GONE); return; }
        banner.setText("⚠ Setup baaki hai: " + android.text.TextUtils.join(", ", issues) + "  — tap karke Settings kholo");
        banner.setVisibility(View.VISIBLE);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void buildQuickRow() {
        LinearLayout row = findViewById(R.id.quickRow);
        String[][] items = {{"▶", "YouTube", "youtube"}, {"💬", "WhatsApp", "whatsapp"},
                {"📷", "Instagram", "instagram"}, {"👍", "Facebook", "facebook"}};
        for (final String[] it : items) {
            TextView tv = new TextView(this);
            tv.setText(it[0] + "\n" + it[1]);
            tv.setTextColor(0xFFE6E6F5);
            tv.setTextSize(12);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, dp(10), 0, dp(10));
            tv.setBackgroundResource(R.drawable.bg_chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(4), 0, dp(4), 0);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> {
                String pkg = new ActionRouter(this).findPackage(it[2]);
                Intent launch = pkg == null ? null : getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) startActivity(launch);
                else Toast.makeText(this, it[1] + " installed nahi hai", Toast.LENGTH_SHORT).show();
            });
            row.addView(tv);
        }
    }

    private void applyState(int st, String text) {
        int orbState = OrbView.IDLE;
        if (st == JanuService.ST_LISTEN) orbState = OrbView.LISTENING;
        else if (st == JanuService.ST_THINK) orbState = OrbView.THINKING;
        else if (st == JanuService.ST_SPEAK) orbState = OrbView.SPEAKING;
        orb.setState(orbState);
        status.setText(text == null || text.isEmpty() ? "Janu" : text);
    }

    // ------------------------------------------------------------------ JanuService.UiListener

    @Override public void onState(int state, String s) { applyState(state, s); }
    @Override public void onText(String who, String text) { transcript.setText(who + ": " + text); }
    @Override public void onLevel(float level) { orb.setLevel(level); }
}
